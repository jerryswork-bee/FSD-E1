-- ============================================
-- E-Commerce Database Setup
-- Run this in phpMyAdmin or MySQL CLI
-- ============================================

CREATE DATABASE IF NOT EXISTS ecommerce_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ecommerce_db;

-- Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    reset_token VARCHAR(255) DEFAULT NULL,
    reset_expires DATETIME DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Categories Table
CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    icon VARCHAR(50) DEFAULT '🛍️',
    slug VARCHAR(100) UNIQUE NOT NULL
);

-- Products Table
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT NOT NULL,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    original_price DECIMAL(10,2) DEFAULT NULL,
    rating DECIMAL(3,2) DEFAULT 4.00,
    reviews_count INT DEFAULT 0,
    warranty VARCHAR(50) DEFAULT NULL,
    image_url VARCHAR(500) NOT NULL,
    badge VARCHAR(50) DEFAULT NULL,
    stock INT DEFAULT 100,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id)
);

-- Cart Table
CREATE TABLE IF NOT EXISTS cart (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT DEFAULT 1,
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    UNIQUE KEY unique_cart_item (user_id, product_id)
);

-- Orders Table
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    total DECIMAL(10,2) NOT NULL,
    status ENUM('pending','processing','shipped','delivered','cancelled') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Insert Categories
INSERT INTO categories (name, icon, slug) VALUES
('Electronics', '⚡', 'electronics'),
('Dresses', '👗', 'dresses'),
('Home Accessories', '🏠', 'home-accessories'),
('Sports Kit', '🏋️', 'sports-kit'),
('Stationery', '✏️', 'stationery');

-- Insert Products
INSERT INTO products (category_id, name, description, price, original_price, rating, reviews_count, warranty, image_url, badge, stock) VALUES
-- Electronics (category_id=1)
(1, 'Sony WH-1000XM5 Headphones', 'Industry-leading noise cancellation with 30-hour battery life and premium sound quality', 329.99, 399.99, 4.8, 2847, '2 Year Warranty', 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&q=80', 'BESTSELLER', 85),
(1, 'Samsung 4K Smart TV 55"', 'Crystal UHD display with built-in Alexa and premium picture engine for vivid colors', 699.99, 899.99, 4.7, 1923, '3 Year Warranty', 'https://images.unsplash.com/photo-1593359677879-a4bb92f4834c?w=400&q=80', 'HOT', 42),
(1, 'MacBook Air M2', 'Apple Silicon M2 chip with 18-hour battery, Liquid Retina display, ultralight design', 1199.99, 1299.99, 4.9, 3241, '1 Year AppleCare', 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400&q=80', 'NEW', 30),
(1, 'iPad Pro 11" M4', 'Stunning Liquid Retina display with M4 chip, perfect for creativity and productivity', 799.99, 899.99, 4.8, 1654, '1 Year Warranty', 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=400&q=80', 'TRENDING', 55),
(1, 'Canon EOS R50 Camera', 'Mirrorless camera with 24.2MP sensor, 4K video, and beginner-friendly controls', 749.99, 849.99, 4.6, 987, '2 Year Warranty', 'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400&q=80', NULL, 25),

-- Dresses (category_id=2)
(2, 'Floral Maxi Dress', 'Elegant flowing floral pattern maxi dress perfect for summer occasions and beach outings', 89.99, 129.99, 4.5, 743, NULL, 'https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?w=400&q=80', 'SUMMER', 150),
(2, 'Classic Little Black Dress', 'Timeless LBD with a flattering A-line silhouette, premium fabric, cocktail-ready style', 119.99, 159.99, 4.7, 1205, NULL, 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=400&q=80', 'CLASSIC', 200),
(2, 'Bohemian Wrap Dress', 'Free-spirited boho wrap dress with earthy tones, relaxed fit, and adjustable tie waist', 69.99, 99.99, 4.4, 521, NULL, 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=400&q=80', NULL, 120),
(2, 'Evening Gown Sequin', 'Glamorous sequin evening gown with a dramatic sweep train for formal events', 249.99, 349.99, 4.8, 412, NULL, 'https://images.unsplash.com/photo-1566479179817-4a154bff46d1?w=400&q=80', 'LUXURY', 45),
(2, 'Casual Linen Sundress', 'Breathable linen sundress with adjustable straps, pockets, and relaxed summer feel', 54.99, 79.99, 4.3, 892, NULL, 'https://images.unsplash.com/photo-1618244972963-dbee1a7edc95?w=400&q=80', NULL, 180),

-- Home Accessories (category_id=3)
(3, 'Luxury Throw Blanket', 'Ultra-soft sherpa throw blanket in premium materials for cozy evenings at home', 49.99, 69.99, 4.6, 1543, NULL, 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=400&q=80', 'COZY', 300),
(3, 'Ceramic Vase Set (3pcs)', 'Handcrafted minimalist ceramic vases in earthy tones, perfect for modern home décor', 79.99, 109.99, 4.5, 678, NULL, 'https://images.unsplash.com/photo-1578500494198-246f612d3b3d?w=400&q=80', NULL, 85),
(3, 'Smart LED Desk Lamp', 'Touch-control LED lamp with adjustable color temperature, USB charging port built-in', 59.99, 79.99, 4.7, 934, '1 Year Warranty', 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=400&q=80', 'SMART', 120),
(3, 'Aromatherapy Diffuser', 'Ultrasonic essential oil diffuser with 7 LED colors, timer settings, and auto-shutoff', 39.99, 59.99, 4.4, 2134, NULL, 'https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=400&q=80', NULL, 200),
(3, 'Wooden Wall Clock', 'Handcrafted solid wood wall clock with silent quartz movement and minimalist design', 89.99, 119.99, 4.6, 456, NULL, 'https://images.unsplash.com/photo-1563861826100-9cb868fdbe1c?w=400&q=80', 'ARTISAN', 60),

-- Sports Kit (category_id=4)
(4, 'Nike Pro Gym Set', 'Complete 5-piece gym set including resistance bands, gloves, belt, straps and bag', 149.99, 199.99, 4.7, 1876, NULL, 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400&q=80', 'PRO', 90),
(4, 'Yoga Mat Premium', 'Extra-thick 6mm non-slip yoga mat with alignment lines, carrying strap, antimicrobial surface', 79.99, 109.99, 4.8, 3421, NULL, 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=400&q=80', 'TOP RATED', 250),
(4, 'Adjustable Dumbbells Set', 'Space-saving adjustable dumbbells from 5-52.5 lbs with quick-change dial system', 349.99, 449.99, 4.9, 2187, '2 Year Warranty', 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&q=80', 'BESTSELLER', 40),
(4, 'Running Shoes Pro X', 'Lightweight carbon-plated running shoes with superior cushioning and breathable mesh upper', 179.99, 229.99, 4.6, 1654, NULL, 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&q=80', 'FAST', 75),
(4, 'Smart Fitness Watch', 'GPS fitness tracker with heart rate, SpO2, sleep tracking, 7-day battery life', 249.99, 329.99, 4.7, 2341, '1 Year Warranty', 'https://images.unsplash.com/photo-1575311373937-040b8e1fd5b6?w=400&q=80', 'SMART', 110),

-- Stationery (category_id=5)
(5, 'Premium Fountain Pen Set', 'Luxury fountain pen with gold-plated nib, ink cartridges, and elegant gift box packaging', 89.99, 119.99, 4.8, 567, NULL, 'https://images.unsplash.com/photo-1583485088034-697b5bc54ccd?w=400&q=80', 'LUXURY', 80),
(5, 'Leather Hardcover Journal', 'Genuine leather journal with 200 acid-free pages, ribbon bookmark, and lay-flat binding', 44.99, 64.99, 4.7, 1234, NULL, 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400&q=80', 'ARTISAN', 150),
(5, 'Professional Art Set 48pc', 'Complete 48-piece art kit with colored pencils, watercolors, pastels, and sketchbook', 69.99, 99.99, 4.6, 892, NULL, 'https://images.unsplash.com/photo-1513364776144-60967b0f800f?w=400&q=80', NULL, 200),
(5, 'Desk Organizer Set', 'Bamboo desk organizer with multiple compartments for pens, notes, and office supplies', 34.99, 49.99, 4.5, 2145, NULL, 'https://images.unsplash.com/photo-1518455027359-f3f8164ba6bd?w=400&q=80', 'ECO', 300),
(5, 'Sticky Notes Mega Pack', '1200-sheet sticky notes mega pack in 8 neon colors, multiple sizes for ultimate organization', 24.99, 34.99, 4.4, 3876, NULL, 'https://images.unsplash.com/photo-1586281380349-632531db7ed4?w=400&q=80', NULL, 500);
