<?php
// ============================================
// config.php - Database Configuration
// Place this file in your XAMPP htdocs folder
// ============================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');        // Change if different
define('DB_PASS', '');            // Change to your MySQL password
define('DB_NAME', 'ecommerce_db');
define('DB_CHARSET', 'utf8mb4');

// SMTP Config for Forgot Password Email
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'your_email@gmail.com');    // Change this
define('SMTP_PASS', 'your_app_password');        // Gmail App Password
define('SMTP_FROM_NAME', 'ShopNest E-Commerce');

// App Config
define('APP_URL', 'http://localhost/ecommerce');
define('SESSION_LIFETIME', 86400); // 24 hours

// Create PDO connection
function getDB() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ];
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            http_response_code(500);
            die(json_encode(['success' => false, 'message' => 'Database connection failed: ' . $e->getMessage()]));
        }
    }
    return $pdo;
}

// JSON Response Helper
function jsonResponse($success, $message = '', $data = []) {
    header('Content-Type: application/json');
    echo json_encode(array_merge(['success' => $success, 'message' => $message], $data));
    exit;
}

// Start session if not started
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params(['lifetime' => SESSION_LIFETIME, 'httponly' => true]);
    session_start();
}

// CORS headers for API
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}
