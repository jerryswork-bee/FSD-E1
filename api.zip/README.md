# 🛍️ ShopNest — Responsive E-Commerce Interface
## Full-Stack Web Application (PHP + MySQL + HTML5 + Tailwind CSS)

---

## 📁 Project Structure

```
ecommerce/
├── index.html          → Login / Register page (animated)
├── home.html           → Product listing page (Amazon-style)
├── cart.html           → Shopping cart page
├── config.php          → Database configuration
├── database.sql        → MySQL schema + seed data
└── api/
    ├── auth.php        → Register, Login, Logout, Forgot Password
    ├── products.php    → Product listing, search (LIKE), categories
    └── cart.php        → Cart CRUD, session-based state
```

---

## ⚡ Quick Setup (XAMPP)

### Step 1: Install XAMPP
Download from https://www.apachefriends.org and install.

### Step 2: Copy Project Files
```bash
# Copy entire ecommerce/ folder to:
C:\xampp\htdocs\ecommerce\      (Windows)
/Applications/XAMPP/htdocs/ecommerce/   (Mac)
/opt/lampp/htdocs/ecommerce/    (Linux)
```

### Step 3: Start XAMPP Services
- Open XAMPP Control Panel
- Start **Apache** and **MySQL**

### Step 4: Create Database
1. Open phpMyAdmin: http://localhost/phpmyadmin
2. Click **Import** tab
3. Choose `database.sql` and click **Go**

### Step 5: Configure Database (if needed)
Edit `config.php`:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');         // Your MySQL username
define('DB_PASS', '');             // Your MySQL password
define('DB_NAME', 'ecommerce_db');
```

### Step 6: Access the Application
Open browser: **http://localhost/ecommerce/**

---

## 🔧 Email (Forgot Password) Setup

For production email, install **PHPMailer**:
```bash
composer require phpmailer/phpmailer
```

Then update `api/auth.php` → `handleForgotPassword()` to use PHPMailer with your SMTP settings from `config.php`.

For testing, use **Mailtrap.io** (free SMTP sandbox).

---

## 🎯 Features Implemented

### ✅ Authentication (api/auth.php)
- [x] User Registration with validation
- [x] Login with bcrypt password hashing
- [x] Session management (PHP Sessions)
- [x] Password visibility toggle (eye icon)
- [x] Password strength meter
- [x] Confirm password matching indicator
- [x] Forgot Password modal with email reset
- [x] Secure token-based password reset

### ✅ Home Page (home.html)
- [x] Amazon-style layout
- [x] Left sidebar with category navigation
- [x] Mobile drawer (hamburger menu)
- [x] Hero banner with animations
- [x] Category filter chips (navbar)
- [x] Real-time search with LIKE queries
- [x] 25 products across 5 categories (5 per category)
- [x] **Upper section**: Electronics + Dresses + Home Accessories
- [x] **Lower section**: Sports Kit + Stationery
- [x] Color-coded product cards per category
- [x] Product images, name, price, rating, description, badge
- [x] Warranty display where applicable
- [x] Animated Add to Cart button
- [x] Cart notification toast
- [x] Cart badge with item count
- [x] Help & Support modal
- [x] Responsive for all screen sizes

### ✅ Cart Page (cart.html)
- [x] Dynamic cart from database (or localStorage demo)
- [x] Product image, name, category, price
- [x] Quantity stepper (+/−)
- [x] Remove item button
- [x] Line total per item
- [x] Order summary: subtotal, tax (8%), shipping, total
- [x] Free shipping indicator ($50+ threshold)
- [x] "Go to Payment" button
- [x] Payment modal (Card / UPI / COD)
- [x] Card number formatting
- [x] Expiry date formatting
- [x] Delivery address field
- [x] Order success modal
- [x] Clear cart functionality

### ✅ Database (database.sql)
- [x] `users` table with bcrypt passwords
- [x] `categories` table (5 categories)
- [x] `products` table (25 products)
- [x] `cart` table with UNIQUE constraint (no duplicates)
- [x] `orders` table

### ✅ API Endpoints (PHP)
| Endpoint | Method | Description |
|----------|--------|-------------|
| `api/auth.php?action=register` | POST | Register new user |
| `api/auth.php?action=login` | POST | Login |
| `api/auth.php?action=logout` | GET/POST | Logout |
| `api/auth.php?action=forgot_password` | POST | Send reset email |
| `api/auth.php?action=reset_password` | POST | Reset password |
| `api/products.php?action=all` | GET | All products |
| `api/products.php?action=all&search=X` | GET | Search with LIKE |
| `api/products.php?action=all&category=X` | GET | Filter by category |
| `api/cart.php?action=list` | GET | Get user cart |
| `api/cart.php?action=add` | POST | Add to cart |
| `api/cart.php?action=update` | POST | Update quantity |
| `api/cart.php?action=remove` | POST | Remove item |
| `api/cart.php?action=clear` | POST | Clear cart |
| `api/cart.php?action=count` | GET | Get item count |

---

## 🎨 Design Features
- Deep navy dark theme (`#0f1923`)
- Gold accent colors (`#f5a623`)
- Gradient mesh backgrounds
- Glassmorphism cards (backdrop-filter)
- CSS animations: fadeIn, slideIn, cardIn, shimmer
- Hover effects with translateY
- Floating particle system (login page)
- Staggered card reveal animations
- Color-coded product categories:
  - Electronics → Purple/Indigo
  - Dresses → Pink/Rose
  - Home Accessories → Gold/Orange
  - Sports Kit → Green/Emerald
  - Stationery → Cyan/Teal

---

## 🔗 Demo Mode (No Backend Required)
The application works in **demo mode** without a PHP backend:
- Login/Register → stores user in `localStorage`
- Products → embedded in JavaScript
- Cart → stored in `localStorage`
- All UI features work fully

To switch to full backend: place files in XAMPP htdocs, import database, and ensure PHP APIs are reachable.

---

© 2025 ShopNest. All rights reserved.
