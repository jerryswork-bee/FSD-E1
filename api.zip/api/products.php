<?php
// ============================================
// api/products.php - Products API
// ============================================
require_once '../config.php';

$action = $_GET['action'] ?? 'all';
$search = $_GET['search'] ?? '';
$category = $_GET['category'] ?? '';
$limit = (int)($_GET['limit'] ?? 50);

switch ($action) {
    case 'all':
        getProducts($search, $category, $limit);
        break;
    case 'categories':
        getCategories();
        break;
    case 'single':
        getProduct((int)($_GET['id'] ?? 0));
        break;
    default:
        getProducts($search, $category, $limit);
}

function getProducts($search = '', $category = '', $limit = 50) {
    $db = getDB();
    
    $sql = 'SELECT p.*, c.name as category_name, c.icon as category_icon, c.slug as category_slug 
            FROM products p 
            JOIN categories c ON p.category_id = c.id 
            WHERE p.stock > 0';
    
    $params = [];
    
    if (!empty($search)) {
        $sql .= ' AND (p.name LIKE ? OR p.description LIKE ? OR c.name LIKE ?)';
        $searchTerm = '%' . $search . '%';
        $params = array_merge($params, [$searchTerm, $searchTerm, $searchTerm]);
    }
    
    if (!empty($category) && $category !== 'all') {
        $sql .= ' AND c.slug = ?';
        $params[] = $category;
    }
    
    $sql .= ' ORDER BY p.category_id, p.id LIMIT ?';
    $params[] = $limit;
    
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $products = $stmt->fetchAll();
    
    // Group by category
    $grouped = [];
    foreach ($products as $product) {
        $catSlug = $product['category_slug'];
        if (!isset($grouped[$catSlug])) {
            $grouped[$catSlug] = [
                'name' => $product['category_name'],
                'icon' => $product['category_icon'],
                'slug' => $catSlug,
                'products' => []
            ];
        }
        $grouped[$catSlug]['products'][] = $product;
    }
    
    jsonResponse(true, 'Products fetched', [
        'products' => $products,
        'grouped' => array_values($grouped),
        'total' => count($products),
        'search' => $search
    ]);
}

function getCategories() {
    $db = getDB();
    $stmt = $db->query('SELECT c.*, COUNT(p.id) as product_count FROM categories c LEFT JOIN products p ON c.id = p.category_id GROUP BY c.id');
    $categories = $stmt->fetchAll();
    jsonResponse(true, 'Categories fetched', ['categories' => $categories]);
}

function getProduct($id) {
    if (!$id) jsonResponse(false, 'Product ID required');
    
    $db = getDB();
    $stmt = $db->prepare('SELECT p.*, c.name as category_name, c.icon as category_icon FROM products p JOIN categories c ON p.category_id = c.id WHERE p.id = ?');
    $stmt->execute([$id]);
    $product = $stmt->fetch();
    
    if (!$product) jsonResponse(false, 'Product not found');
    
    jsonResponse(true, 'Product fetched', ['product' => $product]);
}
