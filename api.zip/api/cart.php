<?php
// ============================================
// api/cart.php - Cart Management API
// ============================================
require_once '../config.php';

// Require authentication
if (!isset($_SESSION['user_id'])) {
    jsonResponse(false, 'Authentication required', ['redirect' => 'index.html']);
}

$userId = $_SESSION['user_id'];
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';
$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;

switch ($method . '_' . $action) {
    case 'GET_':
    case 'GET_list':
        getCart($userId);
        break;
    case 'POST_add':
        addToCart($userId, $input);
        break;
    case 'POST_update':
        updateCart($userId, $input);
        break;
    case 'POST_remove':
        removeFromCart($userId, $input);
        break;
    case 'POST_clear':
        clearCart($userId);
        break;
    case 'GET_count':
        getCartCount($userId);
        break;
    default:
        getCart($userId);
}

function getCart($userId) {
    $db = getDB();
    $stmt = $db->prepare('
        SELECT c.id as cart_id, c.quantity, 
               p.id as product_id, p.name, p.price, p.original_price, 
               p.image_url, p.warranty, p.rating, p.stock,
               cat.name as category_name
        FROM cart c
        JOIN products p ON c.product_id = p.id
        JOIN categories cat ON p.category_id = cat.id
        WHERE c.user_id = ?
        ORDER BY c.added_at DESC
    ');
    $stmt->execute([$userId]);
    $items = $stmt->fetchAll();
    
    $subtotal = 0;
    foreach ($items as &$item) {
        $item['line_total'] = $item['price'] * $item['quantity'];
        $subtotal += $item['line_total'];
    }
    
    $tax = round($subtotal * 0.08, 2);  // 8% tax
    $shipping = $subtotal > 50 ? 0 : 9.99;
    $total = $subtotal + $tax + $shipping;
    
    jsonResponse(true, 'Cart fetched', [
        'items' => $items,
        'count' => count($items),
        'subtotal' => round($subtotal, 2),
        'tax' => $tax,
        'shipping' => $shipping,
        'total' => round($total, 2)
    ]);
}

function addToCart($userId, $data) {
    $productId = (int)($data['product_id'] ?? 0);
    $quantity = (int)($data['quantity'] ?? 1);
    
    if (!$productId) jsonResponse(false, 'Product ID required');
    if ($quantity < 1) $quantity = 1;
    
    $db = getDB();
    
    // Check product exists and has stock
    $stmt = $db->prepare('SELECT id, stock, name FROM products WHERE id = ? AND stock > 0');
    $stmt->execute([$productId]);
    $product = $stmt->fetch();
    
    if (!$product) jsonResponse(false, 'Product not available');
    
    // Upsert cart item
    $stmt = $db->prepare('
        INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE quantity = quantity + ?
    ');
    $stmt->execute([$userId, $productId, $quantity, $quantity]);
    
    // Get updated count
    $countStmt = $db->prepare('SELECT SUM(quantity) as total FROM cart WHERE user_id = ?');
    $countStmt->execute([$userId]);
    $count = $countStmt->fetchColumn();
    
    jsonResponse(true, $product['name'] . ' added to cart!', [
        'cart_count' => (int)$count,
        'product_name' => $product['name']
    ]);
}

function updateCart($userId, $data) {
    $cartId = (int)($data['cart_id'] ?? 0);
    $quantity = (int)($data['quantity'] ?? 1);
    
    if (!$cartId) jsonResponse(false, 'Cart item ID required');
    if ($quantity < 1) jsonResponse(false, 'Quantity must be at least 1');
    
    $db = getDB();
    
    // Verify ownership and check stock
    $stmt = $db->prepare('
        SELECT c.id, p.stock FROM cart c 
        JOIN products p ON c.product_id = p.id 
        WHERE c.id = ? AND c.user_id = ?
    ');
    $stmt->execute([$cartId, $userId]);
    $item = $stmt->fetch();
    
    if (!$item) jsonResponse(false, 'Cart item not found');
    if ($quantity > $item['stock']) jsonResponse(false, 'Not enough stock available');
    
    $stmt = $db->prepare('UPDATE cart SET quantity = ? WHERE id = ? AND user_id = ?');
    $stmt->execute([$quantity, $cartId, $userId]);
    
    getCart($userId); // Return updated cart
}

function removeFromCart($userId, $data) {
    $cartId = (int)($data['cart_id'] ?? 0);
    
    if (!$cartId) jsonResponse(false, 'Cart item ID required');
    
    $db = getDB();
    $stmt = $db->prepare('DELETE FROM cart WHERE id = ? AND user_id = ?');
    $stmt->execute([$cartId, $userId]);
    
    if ($stmt->rowCount() === 0) jsonResponse(false, 'Item not found');
    
    getCart($userId); // Return updated cart
}

function clearCart($userId) {
    $db = getDB();
    $db->prepare('DELETE FROM cart WHERE user_id = ?')->execute([$userId]);
    jsonResponse(true, 'Cart cleared', ['items' => [], 'count' => 0, 'total' => 0]);
}

function getCartCount($userId) {
    $db = getDB();
    $stmt = $db->prepare('SELECT COALESCE(SUM(quantity), 0) as count FROM cart WHERE user_id = ?');
    $stmt->execute([$userId]);
    $count = $stmt->fetchColumn();
    jsonResponse(true, 'Count fetched', ['count' => (int)$count]);
}
