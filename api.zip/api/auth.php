<?php
// ============================================
// api/auth.php - Authentication API
// ============================================
require_once '../config.php';

$action = $_GET['action'] ?? $_POST['action'] ?? '';
$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;

switch ($action) {
    case 'register':
        handleRegister($input);
        break;
    case 'login':
        handleLogin($input);
        break;
    case 'logout':
        handleLogout();
        break;
    case 'forgot_password':
        handleForgotPassword($input);
        break;
    case 'reset_password':
        handleResetPassword($input);
        break;
    case 'check_session':
        checkSession();
        break;
    default:
        jsonResponse(false, 'Invalid action');
}

function handleRegister($data) {
    $name = trim($data['name'] ?? '');
    $email = trim($data['email'] ?? '');
    $password = $data['password'] ?? '';
    $confirm = $data['confirm_password'] ?? '';

    // Validation
    if (empty($name) || empty($email) || empty($password)) {
        jsonResponse(false, 'All fields are required');
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        jsonResponse(false, 'Invalid email address');
    }
    if (strlen($password) < 8) {
        jsonResponse(false, 'Password must be at least 8 characters');
    }
    if ($password !== $confirm) {
        jsonResponse(false, 'Passwords do not match');
    }

    $db = getDB();
    
    // Check if email exists
    $stmt = $db->prepare('SELECT id FROM users WHERE email = ?');
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        jsonResponse(false, 'Email already registered');
    }

    // Insert user
    $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
    $stmt = $db->prepare('INSERT INTO users (name, email, password) VALUES (?, ?, ?)');
    $stmt->execute([$name, $email, $hash]);
    $userId = $db->lastInsertId();

    // Start session
    $_SESSION['user_id'] = $userId;
    $_SESSION['user_name'] = $name;
    $_SESSION['user_email'] = $email;

    jsonResponse(true, 'Registration successful', [
        'user' => ['id' => $userId, 'name' => $name, 'email' => $email]
    ]);
}

function handleLogin($data) {
    $email = trim($data['email'] ?? '');
    $password = $data['password'] ?? '';

    if (empty($email) || empty($password)) {
        jsonResponse(false, 'Email and password are required');
    }

    $db = getDB();
    $stmt = $db->prepare('SELECT id, name, email, password FROM users WHERE email = ?');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password'])) {
        jsonResponse(false, 'Invalid email or password');
    }

    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_name'] = $user['name'];
    $_SESSION['user_email'] = $user['email'];

    jsonResponse(true, 'Login successful', [
        'user' => ['id' => $user['id'], 'name' => $user['name'], 'email' => $user['email']]
    ]);
}

function handleLogout() {
    session_destroy();
    jsonResponse(true, 'Logged out successfully');
}

function checkSession() {
    if (isset($_SESSION['user_id'])) {
        jsonResponse(true, 'Session active', [
            'user' => [
                'id' => $_SESSION['user_id'],
                'name' => $_SESSION['user_name'],
                'email' => $_SESSION['user_email']
            ]
        ]);
    } else {
        jsonResponse(false, 'Not authenticated');
    }
}

function handleForgotPassword($data) {
    $email = trim($data['email'] ?? '');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        jsonResponse(false, 'Invalid email address');
    }

    $db = getDB();
    $stmt = $db->prepare('SELECT id, name FROM users WHERE email = ?');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    // Always return success to prevent email enumeration
    if (!$user) {
        jsonResponse(true, 'If that email exists, a reset link has been sent');
    }

    $token = bin2hex(random_bytes(32));
    $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));

    $stmt = $db->prepare('UPDATE users SET reset_token = ?, reset_expires = ? WHERE id = ?');
    $stmt->execute([$token, $expires, $user['id']]);

    $resetLink = APP_URL . '/reset_password.php?token=' . $token;

    // Send email using PHP mail() - For production use PHPMailer with SMTP
    $to = $email;
    $subject = 'ShopNest - Password Reset Request';
    $message = "Hello {$user['name']},\n\n";
    $message .= "You requested a password reset. Click the link below to reset your password:\n\n";
    $message .= $resetLink . "\n\n";
    $message .= "This link expires in 1 hour.\n\n";
    $message .= "If you didn't request this, ignore this email.\n\n";
    $message .= "ShopNest Team";
    $headers = "From: noreply@shopnest.com\r\nX-Mailer: PHP/" . phpversion();

    mail($to, $subject, $message, $headers);

    jsonResponse(true, 'Password reset link sent to your email');
}

function handleResetPassword($data) {
    $token = $data['token'] ?? '';
    $password = $data['password'] ?? '';
    $confirm = $data['confirm_password'] ?? '';

    if (empty($token) || empty($password)) {
        jsonResponse(false, 'Invalid request');
    }
    if ($password !== $confirm) {
        jsonResponse(false, 'Passwords do not match');
    }
    if (strlen($password) < 8) {
        jsonResponse(false, 'Password must be at least 8 characters');
    }

    $db = getDB();
    $stmt = $db->prepare('SELECT id FROM users WHERE reset_token = ? AND reset_expires > NOW()');
    $stmt->execute([$token]);
    $user = $stmt->fetch();

    if (!$user) {
        jsonResponse(false, 'Invalid or expired reset token');
    }

    $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
    $stmt = $db->prepare('UPDATE users SET password = ?, reset_token = NULL, reset_expires = NULL WHERE id = ?');
    $stmt->execute([$hash, $user['id']]);

    jsonResponse(true, 'Password reset successful');
}
